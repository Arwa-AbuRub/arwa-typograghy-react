import './App.css'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card'
import { Button } from './components/ui/button'
import { Badge } from './components/ui/badge'
import { Separator } from './components/ui/separator'
import { ChevronDown, ChevronUp, Palette, Type, Eye, Lightbulb } from 'lucide-react'

// Import images
import typographyBounce from './assets/typography_bounce.png'
import fontPairing from './assets/font_pairing.png'
import kerningExample from './assets/kerning_example.png'
import tealRedPalette from './assets/teal_red_palette.png'
import colorPsychologyUx from './assets/color_psychology_ux.png'

function App() {
  const [expandedSections, setExpandedSections] = useState({})

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }))
  }

  const QASection = ({ id, question, children, icon: Icon, color }) => (
    <Card className="mb-6 overflow-hidden transition-all duration-300 hover:shadow-lg">
      <CardHeader 
        className={`cursor-pointer ${color} text-white`}
        onClick={() => toggleSection(id)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon className="h-6 w-6" />
            <CardTitle className="text-lg">{question}</CardTitle>
          </div>
          {expandedSections[id] ? <ChevronUp /> : <ChevronDown />}
        </div>
      </CardHeader>
      {expandedSections[id] && (
        <CardContent className="p-6 bg-white">
          {children}
        </CardContent>
      )}
    </Card>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
              Typography & Color Theory
            </h1>
            <p className="text-xl text-gray-600 mb-4">
              A Design Exploration by <span className="font-semibold text-purple-600">Arwa Abu Rub</span>
            </p>
            <div className="flex justify-center gap-2">
              <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                <Type className="h-3 w-3 mr-1" />
                Typography
              </Badge>
              <Badge variant="secondary" className="bg-pink-100 text-pink-700">
                <Palette className="h-3 w-3 mr-1" />
                Color Theory
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Introduction */}
        <Card className="mb-8 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-4">✨ Welcome to My Design Journey!</h2>
            <p className="text-lg leading-relaxed">
              Hey there! I'm excited to share my exploration of typography and color theory with you. 
              These aren't just design principles – they're the secret ingredients that make designs come alive! 
              Click on each question below to discover the magic behind great design. 🎨
            </p>
          </CardContent>
        </Card>

        {/* Typography Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
            <Type className="h-8 w-8 text-purple-600" />
            Typography Questions
          </h2>

          <QASection 
            id="typography-tone" 
            question="What does typography as tone of voice mean to you? 🗣️"
            icon={Type}
            color="bg-gradient-to-r from-blue-500 to-purple-600"
          >
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                Typography is like the personality of your words! Just like how your voice can sound excited, 
                serious, or playful, fonts have their own "voices" too. They can whisper elegance, shout excitement, 
                or speak with authority – all without saying a single word out loud! 
              </p>
              
              <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400">
                <h4 className="font-semibold text-blue-800 mb-2">🎭 Font Personalities:</h4>
                <ul className="space-y-2 text-blue-700">
                  <li><strong>Serif fonts:</strong> The wise professors - traditional, trustworthy, sophisticated</li>
                  <li><strong>Sans-serif fonts:</strong> The modern minimalists - clean, friendly, approachable</li>
                  <li><strong>Script fonts:</strong> The artists - elegant, creative, personal</li>
                  <li><strong>Display fonts:</strong> The attention-seekers - bold, dramatic, memorable</li>
                </ul>
              </div>

              <div className="text-center">
                <img 
                  src={typographyBounce} 
                  alt="Typography example showing BOUNCE!" 
                  className="mx-auto rounded-lg shadow-md max-w-md"
                />
                <p className="text-sm text-gray-600 mt-2 italic">
                  See how "BOUNCE!" literally looks bouncy? That's typography talking! 🏀
                </p>
              </div>
            </div>
          </QASection>

          <QASection 
            id="font-pairing" 
            question="Find a font pair that shouldn't work together… but does! 💕"
            icon={Lightbulb}
            color="bg-gradient-to-r from-green-500 to-teal-600"
          >
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                Meet the ultimate odd couple: <strong>Amatic SC Bold</strong> and <strong>Poppins Medium</strong>! 
                It's like pairing a free-spirited artist with a structured engineer – they're complete opposites, 
                but somehow they create magic together! ✨
              </p>

              <div className="text-center">
                <img 
                  src={fontPairing} 
                  alt="Font pairing example" 
                  className="mx-auto rounded-lg shadow-md max-w-md"
                />
              </div>

              <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-400">
                <h4 className="font-semibold text-green-800 mb-2">💡 Why This Unlikely Duo Works:</h4>
                <ul className="space-y-2 text-green-700">
                  <li><strong>Contrast is key:</strong> The hand-drawn charm meets geometric precision</li>
                  <li><strong>Clear roles:</strong> Amatic grabs attention, Poppins delivers information</li>
                  <li><strong>Balance:</strong> Playful energy balanced with professional reliability</li>
                  <li><strong>Harmony:</strong> They complement rather than compete with each other</li>
                </ul>
              </div>

              <p className="text-gray-600 italic text-center">
                Sometimes the best relationships are between opposites! 💫
              </p>
            </div>
          </QASection>

          <QASection 
            id="typographic-details" 
            question="What's a subtle typographic detail that makes a big difference? 🔍"
            icon={Eye}
            color="bg-gradient-to-r from-orange-500 to-red-600"
          >
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                Let me introduce you to the unsung heroes of typography: <strong>kerning, tracking, and ligatures</strong>! 
                These tiny adjustments are like the seasoning in cooking – you might not notice them, but they make 
                ALL the difference between amateur and professional design! 👨‍🍳
              </p>

              <div className="text-center">
                <img 
                  src={kerningExample} 
                  alt="Kerning example showing before and after" 
                  className="mx-auto rounded-lg shadow-md max-w-lg"
                />
                <p className="text-sm text-gray-600 mt-2 italic">
                  See the difference? Proper kerning makes text feel just right! ✨
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-400">
                  <h4 className="font-semibold text-orange-800 mb-2">📏 Kerning</h4>
                  <p className="text-orange-700 text-sm">
                    Adjusting space between individual letter pairs. Like giving each letter its personal space!
                  </p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-400">
                  <h4 className="font-semibold text-red-800 mb-2">📐 Tracking</h4>
                  <p className="text-red-700 text-sm">
                    Uniform spacing across all letters. Making sure everyone gets equal treatment!
                  </p>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg border-l-4 border-pink-400">
                  <h4 className="font-semibold text-pink-800 mb-2">🔗 Ligatures</h4>
                  <p className="text-pink-700 text-sm">
                    Special combined letters (like 'fi' or 'fl') that prevent awkward collisions!
                  </p>
                </div>
              </div>
            </div>
          </QASection>
        </div>

        <Separator className="my-12" />

        {/* Color Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
            <Palette className="h-8 w-8 text-pink-600" />
            Color Questions
          </h2>

          <QASection 
            id="unexpected-colors" 
            question="Pick two colors you wouldn't expect to work together, but have seen used successfully! 🎨"
            icon={Palette}
            color="bg-gradient-to-r from-teal-500 to-cyan-600"
          >
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                Drumroll please... 🥁 <strong>Teal and Red</strong>! I know, I know – it sounds like a recipe for 
                disaster, right? But when done thoughtfully, this combo creates the most sophisticated and 
                inviting spaces. It's like watching two rival teams become best friends! 🤝
              </p>

              <div className="text-center">
                <img 
                  src={tealRedPalette} 
                  alt="Teal and red color palette example" 
                  className="mx-auto rounded-lg shadow-md max-w-lg"
                />
              </div>

              <div className="bg-teal-50 p-4 rounded-lg border-l-4 border-teal-400">
                <h4 className="font-semibold text-teal-800 mb-2">🏠 Why This Kitchen Combo Works:</h4>
                <ul className="space-y-2 text-teal-700">
                  <li><strong>Muted magic:</strong> Not bright, screaming colors – sophisticated, earthy tones</li>
                  <li><strong>Copper bridge:</strong> Warm copper accents connect the cool teal and warm red</li>
                  <li><strong>Natural balance:</strong> Wood elements provide a neutral foundation</li>
                  <li><strong>Emotional harmony:</strong> Feels like cozy autumn days and falling leaves 🍂</li>
                </ul>
              </div>

              <p className="text-gray-600 italic text-center">
                Sometimes the most unexpected friendships are the strongest! 💪
              </p>
            </div>
          </QASection>

          <QASection 
            id="high-contrast-fails" 
            question="When does high contrast hurt rather than help a design? 😵"
            icon={Eye}
            color="bg-gradient-to-r from-red-500 to-pink-600"
          >
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                High contrast is usually the hero of accessibility, but sometimes even heroes can go too far! 
                It's like turning the volume up to 11 – sometimes you just need to chill a bit. 😅
              </p>

              <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-400">
                <h4 className="font-semibold text-red-800 mb-2">⚠️ When High Contrast Becomes the Villain:</h4>
                <ul className="space-y-2 text-red-700">
                  <li><strong>Eye strain city:</strong> Pure black on pure white can be exhausting to read</li>
                  <li><strong>Hierarchy chaos:</strong> When everything screams, nothing gets heard</li>
                  <li><strong>Mood killer:</strong> Too harsh for elegant, subtle brand aesthetics</li>
                  <li><strong>Accessibility paradox:</strong> Can hurt people with photophobia or certain vision conditions</li>
                </ul>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                <h4 className="font-semibold text-yellow-800 mb-2">📚 Real-World Oops Moment:</h4>
                <p className="text-yellow-700">
                  Colorado State University's Aggie Orange and CSU Green combo looks great on a logo, 
                  but fails accessibility tests for regular text. Beautiful? Yes. Readable for everyone? 
                  Not so much. It's a perfect example of when aesthetics and accessibility don't shake hands! 🤝❌
                </p>
              </div>
            </div>
          </QASection>

          <QASection 
            id="color-psychology" 
            question="How can color be used to manipulate emotion or behavior in UX or marketing? 🧠"
            icon={Lightbulb}
            color="bg-gradient-to-r from-purple-500 to-indigo-600"
          >
            <div className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                Colors are basically emotional wizards! 🧙‍♀️ They can make you feel calm, excited, trustworthy, 
                or even hungry (looking at you, McDonald's red and yellow!). It's like having a secret 
                superpower to influence how people feel and act.
              </p>

              <div className="text-center">
                <img 
                  src={colorPsychologyUx} 
                  alt="Color psychology in UX design example" 
                  className="mx-auto rounded-lg shadow-md max-w-lg"
                />
                <p className="text-sm text-gray-600 mt-2 italic">
                  Same product, different vibes! Color changes everything! 🎭
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-400">
                  <h4 className="font-semibold text-purple-800 mb-2">💎 Luxury Strategy</h4>
                  <p className="text-purple-700 text-sm mb-2">
                    Deep purples and golds whisper "exclusive" and "premium quality"
                  </p>
                  <Badge className="bg-purple-100 text-purple-700">Sophisticated • Exclusive • Premium</Badge>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-400">
                  <h4 className="font-semibold text-orange-800 mb-2">⚡ Urgency Strategy</h4>
                  <p className="text-orange-700 text-sm mb-2">
                    Bright reds and oranges scream "Act now!" and "Limited time!"
                  </p>
                  <Badge className="bg-orange-100 text-orange-700">Urgent • Exciting • Action</Badge>
                </div>
              </div>

              <div className="bg-indigo-50 p-4 rounded-lg border-l-4 border-indigo-400">
                <h4 className="font-semibold text-indigo-800 mb-2">🛒 E-commerce Magic Trick:</h4>
                <p className="text-indigo-700">
                  A red "Buy Now!" button creates urgency and excitement, perfect for flash sales. 
                  But a gold "Add to Cart" button on a luxury site suggests exclusivity and quality. 
                  Same action, completely different emotional journey! 🎢
                </p>
              </div>
            </div>
          </QASection>
        </div>

        {/* Footer */}
        <Card className="bg-gradient-to-r from-gray-800 to-gray-900 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Thanks for Exploring with Me! 🌟</h3>
            <p className="text-gray-300 leading-relaxed mb-4">
              I hope this journey through typography and color theory has been as exciting for you as it was for me! 
              Remember, great design isn't just about making things look pretty – it's about creating experiences 
              that connect, communicate, and inspire. Keep experimenting, keep learning, and most importantly, 
              have fun with your designs! 
            </p>
            <p className="text-lg font-semibold text-purple-300">
              Happy designing! ✨
            </p>
            <p className="text-sm text-gray-400 mt-4">
              — Arwa Abu Rub
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

export default App
